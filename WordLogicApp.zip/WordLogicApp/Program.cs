using System.Net;
using System.Net.Sockets;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

var localIp = GetLocalIPAddress();
var port = builder.Configuration["PORT"] ?? "6010";

builder.WebHost.UseUrls($"http://{localIp}:{port}");

var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
app.Run();

// Display connection info


Console.WriteLine($"  Local:   http://localhost:{port}");
Console.WriteLine($"  Network: http://{localIp}:{port}");

static string GetLocalIPAddress()
{
    try
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }
        }
        return "localhost";
    }
    catch
    {
        return "localhost";
    }
}